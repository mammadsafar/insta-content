# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: workflow.spec.ts >> owner performs real upload, feedback, changes, approval, download, publication and analytics through the interface
- Location: tests/e2e/workflow.spec.ts:4:1

# Error details

```
TimeoutError: locator.fill: Timeout 10000ms exceeded.
Call log:
  - waiting for getByLabel('کپشن', { exact: true })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - complementary [ref=e4]:
    - generic [ref=e5]:
      - strong [ref=e13]: روز
      - generic [ref=e14]: ROOZ
    - paragraph [ref=e15]: فضای کار محتوای تیم
    - navigation "بخش‌های اصلی" [ref=e16]:
      - button "امروز" [ref=e17] [cursor=pointer]
      - button "صفحه‌ها" [ref=e21] [cursor=pointer]
      - button "گزارش‌ها" [ref=e26] [cursor=pointer]
    - generic [ref=e30]:
      - paragraph [ref=e34]: همراه تیم،از ایده تا انتشار.
      - text: نسخه داخلی • روز
    - button "T Test owner مالک فضای کار" [ref=e35] [cursor=pointer]:
      - generic [ref=e36]: T
      - generic [ref=e37]:
        - strong [ref=e38]: Test owner
        - generic [ref=e39]: مالک فضای کار
  - generic [ref=e42]:
    - banner [ref=e43]:
      - generic [ref=e44]: فضای کار / صفحه‌ها
      - generic [ref=e45]:
        - generic [ref=e46]: ۱۴۰۵ مهر ۳۰, پنجشنبه
        - button "اعلان‌ها" [ref=e47] [cursor=pointer]
    - main [ref=e52]:
      - generic [ref=e53]:
        - generic [ref=e54]:
          - button "R Recovery fixture @—" [ref=e55] [cursor=pointer]:
            - generic [ref=e56]: R
            - generic [ref=e57]:
              - strong [ref=e58]: Recovery fixture
              - generic [ref=e59]: "@—"
          - button "R Recovery fixture @—" [ref=e62] [cursor=pointer]:
            - generic [ref=e63]: R
            - generic [ref=e64]:
              - strong [ref=e65]: Recovery fixture
              - generic [ref=e66]: "@—"
          - button "C Content test @—" [ref=e69] [cursor=pointer]:
            - generic [ref=e70]: C
            - generic [ref=e71]:
              - strong [ref=e72]: Content test
              - generic [ref=e73]: "@—"
          - button "C Content test @—" [ref=e76] [cursor=pointer]:
            - generic [ref=e77]: C
            - generic [ref=e78]:
              - strong [ref=e79]: Content test
              - generic [ref=e80]: "@—"
          - button "C Content test @—" [ref=e83] [cursor=pointer]:
            - generic [ref=e84]: C
            - generic [ref=e85]:
              - strong [ref=e86]: Content test
              - generic [ref=e87]: "@—"
          - button "C Content test @—" [ref=e90] [cursor=pointer]:
            - generic [ref=e91]: C
            - generic [ref=e92]:
              - strong [ref=e93]: Content test
              - generic [ref=e94]: "@—"
          - button "C Content test @—" [ref=e97] [cursor=pointer]:
            - generic [ref=e98]: C
            - generic [ref=e99]:
              - strong [ref=e100]: Content test
              - generic [ref=e101]: "@—"
          - button "W Workflow isolated page @—" [ref=e104] [cursor=pointer]:
            - generic [ref=e105]: W
            - generic [ref=e106]:
              - strong [ref=e107]: Workflow isolated page
              - generic [ref=e108]: "@—"
          - button "C Content test @—" [ref=e111] [cursor=pointer]:
            - generic [ref=e112]: C
            - generic [ref=e113]:
              - strong [ref=e114]: Content test
              - generic [ref=e115]: "@—"
          - button "O Other page @—" [ref=e118] [cursor=pointer]:
            - generic [ref=e119]: O
            - generic [ref=e120]:
              - strong [ref=e121]: Other page
              - generic [ref=e122]: "@—"
          - button "C Content test @—" [ref=e125] [cursor=pointer]:
            - generic [ref=e126]: C
            - generic [ref=e127]:
              - strong [ref=e128]: Content test
              - generic [ref=e129]: "@—"
          - button "W Workflow isolated page @—" [ref=e132] [cursor=pointer]:
            - generic [ref=e133]: W
            - generic [ref=e134]:
              - strong [ref=e135]: Workflow isolated page
              - generic [ref=e136]: "@—"
          - button "پ پیکربندی @test_page" [ref=e139] [cursor=pointer]:
            - generic [ref=e140]: پ
            - generic [ref=e141]:
              - strong [ref=e142]: پیکربندی
              - generic [ref=e143]: "@test_page"
          - button "W Workflow isolated page @—" [ref=e146] [cursor=pointer]:
            - generic [ref=e147]: W
            - generic [ref=e148]:
              - strong [ref=e149]: Workflow isolated page
              - generic [ref=e150]: "@—"
          - button "پ پیکربندی @test_page" [ref=e153] [cursor=pointer]:
            - generic [ref=e154]: پ
            - generic [ref=e155]:
              - strong [ref=e156]: پیکربندی
              - generic [ref=e157]: "@test_page"
          - button "C Content test @—" [ref=e160] [cursor=pointer]:
            - generic [ref=e161]: C
            - generic [ref=e162]:
              - strong [ref=e163]: Content test
              - generic [ref=e164]: "@—"
          - button "O Other page @—" [ref=e167] [cursor=pointer]:
            - generic [ref=e168]: O
            - generic [ref=e169]:
              - strong [ref=e170]: Other page
              - generic [ref=e171]: "@—"
          - button "W Workflow isolated page @—" [ref=e174] [cursor=pointer]:
            - generic [ref=e175]: W
            - generic [ref=e176]:
              - strong [ref=e177]: Workflow isolated page
              - generic [ref=e178]: "@—"
          - button "O Operations @—" [ref=e181] [cursor=pointer]:
            - generic [ref=e182]: O
            - generic [ref=e183]:
              - strong [ref=e184]: Operations
              - generic [ref=e185]: "@—"
          - button "H Hidden reports @—" [ref=e188] [cursor=pointer]:
            - generic [ref=e189]: H
            - generic [ref=e190]:
              - strong [ref=e191]: Hidden reports
              - generic [ref=e192]: "@—"
          - button "پ پیکربندی @test_page" [ref=e195] [cursor=pointer]:
            - generic [ref=e196]: پ
            - generic [ref=e197]:
              - strong [ref=e198]: پیکربندی
              - generic [ref=e199]: "@test_page"
          - button "C Content test @—" [ref=e202] [cursor=pointer]:
            - generic [ref=e203]: C
            - generic [ref=e204]:
              - strong [ref=e205]: Content test
              - generic [ref=e206]: "@—"
          - button "W Workflow isolated page @—" [ref=e209] [cursor=pointer]:
            - generic [ref=e210]: W
            - generic [ref=e211]:
              - strong [ref=e212]: Workflow isolated page
              - generic [ref=e213]: "@—"
          - button "O Operations @—" [ref=e216] [cursor=pointer]:
            - generic [ref=e217]: O
            - generic [ref=e218]:
              - strong [ref=e219]: Operations
              - generic [ref=e220]: "@—"
          - button "H Hidden reports @—" [ref=e223] [cursor=pointer]:
            - generic [ref=e224]: H
            - generic [ref=e225]:
              - strong [ref=e226]: Hidden reports
              - generic [ref=e227]: "@—"
          - button "C Content test @—" [ref=e230] [cursor=pointer]:
            - generic [ref=e231]: C
            - generic [ref=e232]:
              - strong [ref=e233]: Content test
              - generic [ref=e234]: "@—"
          - button "O Other page @—" [ref=e237] [cursor=pointer]:
            - generic [ref=e238]: O
            - generic [ref=e239]:
              - strong [ref=e240]: Other page
              - generic [ref=e241]: "@—"
        - generic [ref=e245]:
          - generic [ref=e246]: میز محتوای صفحه
          - heading "Recovery fixture" [level=1] [ref=e247]
          - paragraph [ref=e248]: از اولین ایده تا انتشار؛ همه‌چیز در یک جریان.
        - generic [ref=e249]:
          - button "پست‌ها" [ref=e250] [cursor=pointer]
          - button "استوری‌ها" [ref=e253] [cursor=pointer]
        - generic [ref=e259]:
          - generic [ref=e260]:
            - strong [ref=e261]: ۰روز
            - generic [ref=e262]: پوشش پیوسته تأییدشده
          - generic [ref=e263]:
            - strong [ref=e264]: ۱۴
            - generic [ref=e265]: جایگاه خالی در ۷ روز
          - generic [ref=e266]:
            - strong [ref=e267]: ۰
            - generic [ref=e268]: منتظر تأیید
          - generic [ref=e269]:
            - strong [ref=e270]: ۱
            - generic [ref=e271]: نیازمند اصلاح
          - generic [ref=e272]:
            - strong [ref=e273]:
              - text: ۰
              - generic [ref=e274]: / ۰
            - generic [ref=e275]: منتشرشده / برنامه امروز
        - generic [ref=e276]:
          - generic [ref=e277]:
            - button "مدیریت" [ref=e278] [cursor=pointer]
            - button "نمای صفحه" [ref=e280] [cursor=pointer]
          - generic [ref=e283]:
            - button "الگوی برنامه" [ref=e284] [cursor=pointer]
            - button "محتوای تازه" [ref=e288] [cursor=pointer]
        - generic [ref=e290]:
          - button "پیشِ رو" [ref=e291] [cursor=pointer]
          - button "منتظر تأیید" [ref=e292] [cursor=pointer]
          - button "اصلاح" [ref=e293] [cursor=pointer]
          - button "تأییدشده" [ref=e294] [cursor=pointer]
          - button "منتشرشده" [ref=e295] [cursor=pointer]
          - button "بدون آمار" [ref=e296] [cursor=pointer]
          - button "همه" [ref=e297] [cursor=pointer]
          - button "زباله‌دان" [ref=e298] [cursor=pointer]
        - textbox "جستجوی محتوا" [ref=e299]:
          - /placeholder: جستجوی عنوان یا موضوع…
        - button "آزمون کامل مرورگر 1792684826744 نیازمند اصلاح آزمون کامل مرورگر 1792684826744 بدون تاریخ پست تصویری ۲" [ref=e301] [cursor=pointer]:
          - generic [ref=e302]:
            - img "آزمون کامل مرورگر 1792684826744" [ref=e303]
            - generic [ref=e304]: نیازمند اصلاح
          - generic [ref=e305]:
            - heading "آزمون کامل مرورگر 1792684826744" [level=3] [ref=e306]
            - paragraph [ref=e307]: بدون تاریخ
            - generic [ref=e308]:
              - generic [ref=e309]: پست تصویری
              - generic [ref=e310]: ۲
        - dialog "آزمون کامل مرورگر 1792684826744" [ref=e314]:
          - generic [ref=e315]:
            - heading "آزمون کامل مرورگر 1792684826744" [level=2] [ref=e316]
            - button "بستن" [ref=e317] [cursor=pointer]
          - generic [ref=e321]:
            - generic [ref=e322]:
              - generic [ref=e323]:
                - button "شبکه" [ref=e324] [cursor=pointer]
                - button "فید" [ref=e325] [cursor=pointer]
                - button "ریلز" [ref=e326] [cursor=pointer]
                - button "استوری" [ref=e327] [cursor=pointer]
              - generic [ref=e328]:
                - generic [ref=e329]:
                  - generic [ref=e330]: R
                  - strong [ref=e331]: Recovery fixture
                - img "آزمون کامل مرورگر 1792684826744" [ref=e337]
                - paragraph [ref=e349]:
                  - strong [ref=e350]: Recovery fixture
                  - text: کپشن اولیه خط دوم
              - generic [ref=e352] [cursor=pointer]:
                - checkbox "راهنمای محدوده امن" [ref=e353]
                - text: راهنمای محدوده امن
              - strong [ref=e362]: موسیقی اضافه لازم نیست
              - text: نمایش تقریبی برای بررسی ترکیب و کادر؛ این سامانه وابسته به اینستاگرام نیست.
            - generic [ref=e363]:
              - generic [ref=e364]:
                - generic [ref=e365]: نیازمند اصلاح
                - generic [ref=e366]: نسخه ۱
              - generic [ref=e367]: بدون تاریخ
              - generic [ref=e370]:
                - button "ویرایش" [ref=e371] [cursor=pointer]
                - button "برنامه انتشار" [ref=e375] [cursor=pointer]
              - generic [ref=e378]:
                - button "روند انتشار" [ref=e379] [cursor=pointer]
                - button "بازخورد ۲" [ref=e380] [cursor=pointer]
                - button "سابقه" [ref=e381] [cursor=pointer]
              - generic [ref=e382]:
                - heading "اصلاح و ارسال دوباره" [level=3] [ref=e383]
                - button "ارسال برای تأیید" [ref=e384] [cursor=pointer]
              - group [ref=e385]:
                - generic "جزئیات محتوا +" [ref=e386] [cursor=pointer]
        - dialog "ویرایش محتوا" [ref=e388]:
          - generic [ref=e389]:
            - heading "ویرایش محتوا" [level=2] [ref=e390]
            - button "بستن" [active] [ref=e391] [cursor=pointer]
          - generic [ref=e395]:
            - generic [ref=e396]:
              - generic [ref=e397]:
                - generic [ref=e398]:
                  - generic [ref=e399]: نوع محتوا
                  - combobox "نوع محتوا" [ref=e400]:
                    - option "ریلز / ویدیو"
                    - option "پست تصویری" [selected]
                    - option "اسلاید تصویری"
                    - option "اسلاید ویدیویی"
                    - option "اسلاید ترکیبی"
                - generic [ref=e401]:
                  - generic [ref=e402]: کد یا عنوان کوتاه
                  - textbox "کد یا عنوان کوتاه" [ref=e403]: آزمون کامل مرورگر 1792684826744
              - generic [ref=e404]:
                - generic [ref=e405]: فایل‌های محتوا
                - generic [ref=e407] [cursor=pointer]:
                  - strong [ref=e409]: انتخاب فایل
                  - generic [ref=e410]: فایل اصلی شما بدون تغییر نگهداری می‌شود
                  - button "فایل‌های محتوا انتخاب فایل فایل اصلی شما بدون تغییر نگهداری می‌شود ترتیب فایل‌ها همان ترتیب انتشار است. برای جایگزینی، فایل تازه را اضافه و فایل قبلی را حذف کنید." [ref=e411]
                - generic [ref=e412]: ترتیب فایل‌ها همان ترتیب انتشار است. برای جایگزینی، فایل تازه را اضافه و فایل قبلی را حذف کنید.
              - generic [ref=e414]:
                - generic [ref=e415]: "1"
                - img "browser-fixture.png" [ref=e416]
                - generic [ref=e417]: browser-fixture.png
                - button "بالاتر" [disabled] [ref=e418]
                - button "پایین‌تر" [disabled] [ref=e421]
                - button "حذف فایل" [ref=e424] [cursor=pointer]
              - group [ref=e428]:
                - generic "کاور جداگانه +" [ref=e429] [cursor=pointer]
              - generic [ref=e434]:
                - generic [ref=e435]: کپشن
                - textbox "کپشن" [ref=e436]: کپشن اولیه خط دوم
              - group [ref=e437]:
                - generic "سناریو، موضوع و جزئیات محتوا +" [ref=e438] [cursor=pointer]
                - option "بدون موضوع" [selected]
            - generic [ref=e439]:
              - generic [ref=e440]:
                - heading "برنامه و مسئول پیگیری" [level=3] [ref=e441]
                - paragraph [ref=e442]: تغییر برنامه از بخش «برنامه انتشار» انجام می‌شود.
                - generic [ref=e443]:
                  - generic [ref=e444]: مسئول پیگیری
                  - combobox "مسئول پیگیری" [ref=e445]:
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Test owner" [selected]
                    - option "Workflow member"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Workflow member"
                    - option "Member"
                    - option "Workflow member"
                    - option "Member"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Workflow member"
                    - option "Owner"
                    - option "Member"
                    - option "Other"
                    - option "Member"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Workflow member"
                    - option "Owner"
                    - option "Member"
                    - option "Other"
                    - option "Recovery member"
                    - option "Owner"
                    - option "Editor"
                    - option "Suggest"
                    - option "Recovery member"
                - paragraph [ref=e446]: پیش‌نویس هنگام تکمیل فرم در همین نشست نگهداری می‌شود. تأیید نهایی به نسخه مشخص محتوا وابسته است.
              - generic [ref=e447]:
                - heading "موسیقی و دستور انتشار" [level=3] [ref=e448]
                - generic [ref=e449]:
                  - generic [ref=e450]: وضعیت موسیقی
                  - combobox "وضعیت موسیقی" [ref=e451]:
                    - option "موسیقی اضافه لازم نیست" [selected]
                    - option "صدا در فایل نهایی قرار دارد"
                    - option "هنگام انتشار در اینستاگرام اضافه شود"
                - generic [ref=e452]:
                  - generic [ref=e453]: نام قطعه
                  - textbox "نام قطعه" [ref=e454]
                - generic [ref=e455]:
                  - generic [ref=e456]: پیوند موسیقی
                  - textbox "پیوند موسیقی" [ref=e457]
                - generic [ref=e458]:
                  - generic [ref=e459]: یادداشت
                  - textbox "یادداشت" [ref=e460]
                - generic [ref=e461]:
                  - generic [ref=e462]: دستور بلندی صدا
                  - textbox "دستور بلندی صدا" [ref=e463]
                - generic [ref=e464]:
                  - generic [ref=e465]: شروع از ثانیه
                  - spinbutton "شروع از ثانیه" [ref=e466]: "0"
                - generic [ref=e468] [cursor=pointer]:
                  - strong [ref=e470]: انتخاب فایل
                  - generic [ref=e471]: فایل اصلی شما بدون تغییر نگهداری می‌شود
                  - button "انتخاب فایل فایل اصلی شما بدون تغییر نگهداری می‌شود" [ref=e472]
          - generic [ref=e473]:
            - button "ذخیره پیش‌نویس" [ref=e474] [cursor=pointer]
            - button "بستن" [ref=e475] [cursor=pointer]
            - generic [ref=e476]: فقط با تأیید سرور ذخیره می‌شود
    - contentinfo [ref=e477]: روز • فضای روشن کارهای محتوایی
```

# Test source

```ts
  1  | import {test,expect} from '@playwright/test';
  2  | import sharp from 'sharp';
  3  | 
  4  | test('owner performs real upload, feedback, changes, approval, download, publication and analytics through the interface',async({page},info)=>{
  5  |   test.skip(info.project.name!=='desktop-light'||!process.env.E2E_EMAIL||!process.env.E2E_PASSWORD,'Full write workflow uses one isolated desktop test account.');
  6  |   await page.goto('/#pages');
  7  |   await page.getByLabel('ایمیل',{exact:true}).fill(process.env.E2E_EMAIL!);
  8  |   await page.getByLabel('رمز عبور',{exact:true}).fill(process.env.E2E_PASSWORD!);
  9  |   await page.getByRole('button',{name:'ورود به روز'}).click();
  10 |   await page.getByRole('button',{name:'محتوای تازه'}).click();
  11 |   const title=`آزمون کامل مرورگر ${Date.now()}`;
  12 |   await page.getByLabel('کد یا عنوان کوتاه').fill(title);
  13 |   const image=await sharp({create:{width:800,height:1000,channels:3,background:'#c4d5cb'}}).png().toBuffer();
  14 |   await page.locator('input[type=file]').first().setInputFiles({name:'browser-fixture.png',mimeType:'image/png',buffer:image});
  15 |   await expect(page.getByText('آماده',{exact:true})).toBeVisible();
  16 |   await page.getByLabel('کپشن',{exact:true}).fill('کپشن اولیه\nخط دوم');
  17 |   await page.getByRole('button',{name:'ذخیره پیش‌نویس',exact:true}).click();
  18 |   await expect(page.getByRole('dialog',{name:title})).toBeVisible();
  19 |   await page.getByRole('button',{name:'ارسال برای تأیید',exact:true}).click();
  20 |   await page.getByRole('button',{name:/^بازخورد/}).click();
  21 |   await page.getByLabel('متن بازخورد').fill('این پیشنهاد نباید تأیید را باطل کند.');
  22 |   await page.getByRole('button',{name:'ثبت پیشنهاد',exact:true}).click();
  23 |   await page.getByRole('button',{name:'روند انتشار',exact:true}).click();
  24 |   await page.getByLabel('توضیح اصلاح الزامی').fill('متن کپشن اصلاح شود.');
  25 |   await page.getByRole('button',{name:'درخواست اصلاح',exact:true}).click();
  26 |   await page.getByRole('button',{name:'ویرایش',exact:true}).click();
> 27 |   await page.getByLabel('کپشن',{exact:true}).fill('کپشن نهایی\nخط دوم حفظ می‌شود.');
     |                                              ^ TimeoutError: locator.fill: Timeout 10000ms exceeded.
  28 |   await page.getByRole('button',{name:'ذخیره پیش‌نویس',exact:true}).click();
  29 |   await page.getByRole('button',{name:'ارسال برای تأیید',exact:true}).click();
  30 |   await page.getByRole('button',{name:/^تأیید نسخه/}).click();
  31 |   await page.getByRole('button',{name:'رزرو انتشار',exact:true}).click();
  32 |   const downloaded=page.waitForEvent('download');
  33 |   await page.getByRole('link',{name:'دریافت بسته اصلی',exact:true}).click();
  34 |   expect((await downloaded).suggestedFilename()).toMatch(/\.zip$/);
  35 |   await page.getByRole('button',{name:'در اینستاگرام منتشر کردم',exact:true}).click();
  36 |   await expect(page.getByRole('heading',{name:'انتشار ثبت شده',exact:true})).toBeVisible();
  37 |   await page.getByRole('button',{name:'ثبت آمار',exact:true}).click();
  38 |   await page.getByLabel('نقطه مشاهده').selectOption('first_hour');
  39 |   await page.getByLabel('بازدید ساعت اول',{exact:true}).fill('0');
  40 |   await page.getByLabel('حساب‌های دسترسی‌یافته',{exact:true}).fill('0');
  41 |   await page.getByRole('button',{name:'نهایی کردن مشاهده',exact:true}).click();
  42 |   await expect(page.getByRole('status').filter({hasText:'آمار نهایی شد'})).toBeVisible();
  43 | });
  44 | 
```